from django.shortcuts import render,redirect
from accounts.models import *

# Create your views here.

def fooditems(request):
    return render(request,"food.html")

def foodmenu(request):
     items=Item.objects.all()
     context={'items':items}
     return render(request,"todaysmenu.html",context)

def getitemdetails(request):
    item=Item.objects.all()
   
    return render(request,"clickedfooditem.html")

def addfooditem(request):
    if request.method=="POST":
        itemName=request.POST.get('itemName')
        receipe=request.POST.get('receipe')
        price=request.POST.get('price')
        image= request.FILES.get('re_image')
        item=Item.objects.create(
            itemName=itemName,
            receipe=receipe,
            price=price,
            image=image
        )

        item.save()
        return render(request,"addreceipe.html")
    return render(request,"addreceipe.html")

def updatereceipe(request):
    if request.method=="POST":
        itemName=request.POST.get('itemName')
        receipe=request.POST.get('receipe')
        price=request.POST.get('price')
        image= request.FILES.get('re_image')
        item=Item.objects.filter('itemName').update(
            receipe=receipe,
            price=price,
            image=image
        )
        return redirect('/')
    return redirect('/')